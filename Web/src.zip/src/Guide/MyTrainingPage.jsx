import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { API_URL } from '../config';

export default function MyTraining() {
  const location = useLocation();
  const userId = location.state?.userId;

  const [certificates, setCertificates] = useState([]);

  useEffect(() => {
    const fetchCertificates = async () => {
      try {
        const response = await fetch(`${API_URL}/api/training_course/certificates?userId=${userId}`);
        const data = await response.json();
        setCertificates(data);
      } catch (error) {
        console.error('Error fetching certificates:', error);
      }
    };

    fetchCertificates();
  }, [userId]);

  return (
    <div style={styles.container}>
      <h2 style={styles.header}>My Certificates</h2>
      <div style={styles.certificatesList}>
        {certificates.map((certificate) => (
          <div key={certificate.certificateId} style={styles.certificateCard}>
            <h3 style={styles.certificateTitle}>{certificate.certificateName}</h3>
            <img
              src="/images/Cert1.png"
              alt="Certificate"
              style={styles.certificateImage}
            />
            <p style={styles.courseTitle}>Course: {certificate.courseTitle}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  container: {
    backgroundColor: '#f3f7f0',
    padding: '20px',
    minHeight: '100vh',
    fontFamily: 'Arial, sans-serif',
  },
  header: {
    fontSize: '26px',
    fontWeight: 'bold',
    color: '#1B5E20',
    textAlign: 'center',
    marginBottom: '30px',
  },
  certificatesList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
  },
  certificateCard: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '10px',
    border: '1px solid #e0e0e0',
    boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
  },
  certificateTitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#333',
    marginBottom: '10px',
  },
  certificateImage: {
    width: '100%',
    height: 'auto',
    maxHeight: '220px',
    objectFit: 'contain',
    marginBottom: '10px',
  },
  courseTitle: {
    fontSize: '16px',
    color: '#555',
  },
};
