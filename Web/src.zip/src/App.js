// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import AdminHomeScreen from './Admin/AdminHome';
import { AdminIoTDashboard } from './Admin/IotDashboard';
import { TrackProgressPage } from './Admin/TrackProgressPage';
import AddCoursePage from './Admin/AddCoursePage';
import GuideListPage from './Admin/GuideListPage';
import AssignCoursePage from './Admin/AssignCoursePage';
import ILSPage from './Admin/ILSPage';
import CourseInfoPage from './Admin/CourseInfoPage';
import EditCoursePage from './Admin/EditCoursePage';
import AdminPersonal from './Admin/AdminPersonal';
import AdminProfile from './Admin/AdminProfile';
import GuideHomeScreen from './Guide/GuideHomeScreen';
import CertificateView from './Guide/CertificateView';
import MyTrainingPage from './Guide/MyTrainingPage';
import GuidePersonal from './Guide/GuidePersonal';
import GuideProfile from './Guide/GuideProfile';
import GuideLicensePage from './Guide/GuideLIcensePage';
import LicenseDetailsPage from './Guide/LIcenseDetailsPage';
import RenewLicensePage from './Guide/RenewLicensePage';
import BirthdayEdit from './Screen/BirthdayEdit';
import EmailEdit from './Screen/EmailEdit';
import NameEdit from './Screen/NameEdit';
import PhoneEdit from './Screen/PhoneEdit';
import FAQScreen from './Screen/FAQScreen';
import Help from './Screen/Help';
import SPScreen from './Screen/SPScreen';
import GuideNotification from './Guide/GuideNotification';
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AdminHomeScreen />} />
        <Route path="/Admin" element={<AdminHomeScreen />} />
        <Route path="/Guide" element={<GuideHomeScreen />} />
        <Route path="/Guide/GuidePersonal" element={<GuidePersonal />} />
        <Route path="/Guide/CertificateView" element={<CertificateView />} />
        <Route path="/Guide/GuideProfile" element={<GuideProfile />} />
        <Route path="/Guide/GuideLicensePage" element={<GuideLicensePage />} />
        <Route path="/Guide/LicenseDetailsPage" element={<LicenseDetailsPage />} />
        <Route path="/Guide/MyTrainingPage" element={<MyTrainingPage />} />
        <Route path="/Guide/RenewLicensePage" element={<RenewLicensePage />} />
        <Route path="/Guide/GuideNotification" element={<GuideNotification />} />
        
        <Route path="/Admin/IotDashboard" element={<AdminIoTDashboard />} />
        <Route path="/Admin/TrackProgressPage" element={<TrackProgressPage />} />
        <Route path="/Admin/AddCoursePage" element={<AddCoursePage />} />
        <Route path="/Admin/GuideListPage" element={<GuideListPage />} />
        <Route path="/Admin/AssignCoursePage" element={<AssignCoursePage />} />
        <Route path="/Admin/ILSPage" element={<ILSPage />} />
        <Route path="/Admin/CourseInfoPage" element={<CourseInfoPage />} />
        <Route path="/Admin/EditCoursePage" element={<EditCoursePage />} />
        <Route path="/Admin/AdminPersonal" element={<AdminPersonal />} />
        <Route path="/Admin/AdminProfile" element={<AdminProfile />} />
        <Route path="/Screen/BirthdayEdit" element={<BirthdayEdit />} />
        <Route path="/Screen/EmailEdit" element={<EmailEdit />} />
        <Route path="/Screen/NameEdit" element={<NameEdit />} />
        <Route path="/Screen/PhoneEdit" element={<PhoneEdit />} />
        <Route path="/Screen/FAQScreen" element={<FAQScreen />} />
        <Route path="/Screen/Help" element={<Help />} />
        <Route path="/Screen/SPScreen" element={<SPScreen />} />
        {/* Add other routes as needed */}
      </Routes>
    </Router>
  );
}

export default App;
